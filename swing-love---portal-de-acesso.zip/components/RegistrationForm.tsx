
import React, { useState } from 'react';
import { RelationshipStatus, UserProfile } from '../types';

interface RegistrationFormProps {
  onSubmit: (profile: UserProfile) => void;
  isSubmitting: boolean;
}

export const RegistrationForm: React.FC<RegistrationFormProps> = ({ onSubmit, isSubmitting }) => {
  const [formData, setFormData] = useState<UserProfile>({
    name: '',
    age: 18,
    location: '',
    status: RelationshipStatus.COUPLE,
    interests: [],
    whatsapp: '',
    bio: ''
  });

  const [whatsappError, setWhatsappError] = useState('');

  const availableInterests = [
    'Troca de Casal',
    'Menage (MFF)',
    'Menage (MMF)',
    'Cuckold',
    'Exibicionismo',
    'Voyeurismo',
    'BDSM Light',
    'Apenas Amizade'
  ];

  const handleInterestToggle = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const validateWhatsApp = (value: string) => {
    // Apenas números, entre 10 e 11 dígitos (DDD + número)
    const regex = /^\d{10,11}$/;
    return regex.test(value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setWhatsappError('');

    if (!formData.name || !formData.whatsapp || formData.interests.length === 0) {
      alert("Por favor, preencha todos os campos obrigatórios.");
      return;
    }

    if (!validateWhatsApp(formData.whatsapp)) {
      setWhatsappError('O WhatsApp deve conter apenas números com DDD (ex: 11999999999).');
      return;
    }

    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8 bg-slate-900/40 p-6 sm:p-10 rounded-3xl border border-slate-800 backdrop-blur-sm shadow-2xl">
      <div className="space-y-2">
        <h2 className="text-2xl font-serif text-rose-100">Crie seu Perfil VIP</h2>
        <p className="text-slate-400 text-sm">Suas informações são tratadas com total sigilo.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Name */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Como prefere ser chamado?*</label>
          <input
            type="text"
            required
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500/50 transition-all"
            placeholder="Nome ou Apelido"
            value={formData.name}
            onChange={e => setFormData({ ...formData, name: e.target.value })}
          />
        </div>

        {/* Age */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Idade*</label>
          <input
            type="number"
            min="18"
            max="99"
            required
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500/50 transition-all"
            value={formData.age}
            onChange={e => setFormData({ ...formData, age: parseInt(e.target.value) })}
          />
        </div>

        {/* Status */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Status de Relacionamento*</label>
          <select
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500/50 transition-all"
            value={formData.status}
            onChange={e => setFormData({ ...formData, status: e.target.value as RelationshipStatus })}
          >
            {Object.values(RelationshipStatus).map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>
        </div>

        {/* Location */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Cidade/Estado*</label>
          <input
            type="text"
            required
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500/50 transition-all"
            placeholder="Ex: São Paulo - SP"
            value={formData.location}
            onChange={e => setFormData({ ...formData, location: e.target.value })}
          />
        </div>

        {/* WhatsApp */}
        <div className="space-y-2 md:col-span-2">
          <label className="block text-sm font-medium text-slate-300">WhatsApp (DDD + Número)*</label>
          <input
            type="tel"
            required
            inputMode="numeric"
            pattern="\d*"
            className={`w-full bg-slate-800 border rounded-xl px-4 py-3 text-slate-100 focus:outline-none focus:ring-2 transition-all ${
              whatsappError ? 'border-red-500 focus:ring-red-500/50' : 'border-slate-700 focus:ring-rose-500/50'
            }`}
            placeholder="Ex: 11999999999"
            value={formData.whatsapp}
            onChange={e => {
              const val = e.target.value.replace(/\D/g, ''); // Garante apenas números durante a digitação
              setFormData({ ...formData, whatsapp: val });
              if (whatsappError) setWhatsappError('');
            }}
          />
          {whatsappError && (
            <p className="text-red-400 text-xs mt-1 animate-pulse">{whatsappError}</p>
          )}
        </div>
      </div>

      {/* Interests */}
      <div className="space-y-4">
        <label className="block text-sm font-medium text-slate-300">Interesses (Selecione pelo menos um)*</label>
        <div className="flex flex-wrap gap-3">
          {availableInterests.map(interest => (
            <button
              key={interest}
              type="button"
              onClick={() => handleInterestToggle(interest)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all border ${
                formData.interests.includes(interest)
                  ? 'bg-rose-600 border-rose-500 text-white shadow-lg shadow-rose-600/20'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500'
              }`}
            >
              {interest}
            </button>
          ))}
        </div>
      </div>

      {/* Bio */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-slate-300">Sobre você / O que busca?</label>
        <textarea
          rows={3}
          className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500/50 transition-all resize-none"
          placeholder="Conte um pouco sobre suas fantasias e limites..."
          value={formData.bio}
          onChange={e => setFormData({ ...formData, bio: e.target.value })}
        />
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full py-4 bg-gradient-to-r from-rose-600 to-purple-700 text-white font-bold rounded-xl shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed uppercase tracking-widest text-sm"
      >
        {isSubmitting ? 'Validando Cadastro...' : 'Finalizar Cadastro e Entrar no Grupo'}
      </button>
    </form>
  );
};
