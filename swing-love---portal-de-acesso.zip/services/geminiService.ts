
import { GoogleGenAI } from "@google/genai";
import { UserProfile } from "../types";

export const generateWelcomeMessage = async (profile: UserProfile): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const prompt = `
    Você é o anfitrião elegante de um grupo exclusivo de Swing e Lifestyle chamado "Swing Love".
    Um novo membro acaba de se cadastrar com os seguintes dados:
    Nome/Apelido: ${profile.name}
    Idade: ${profile.age}
    Status: ${profile.status}
    Localização: ${profile.location}
    Interesses: ${profile.interests.join(", ")}
    Bio: ${profile.bio}

    Escreva uma mensagem de boas-vindas curta (máximo 3 frases), sofisticada e acolhedora, destacando que o ambiente é seguro e discreto. 
    Use um tom sensual, porém respeitoso. Não use termos vulgares.
    Responda apenas com o texto da mensagem.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "Seja muito bem-vindo ao Swing Love. Prepare-se para momentos inesquecíveis.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Bem-vindo ao nosso círculo exclusivo. O prazer é todo nosso em recebê-lo.";
  }
};
