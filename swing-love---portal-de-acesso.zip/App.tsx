
import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { RegistrationForm } from './components/RegistrationForm';
import { WelcomeScreen } from './components/WelcomeScreen';
import { UserProfile } from './types';
import { generateWelcomeMessage } from './services/geminiService';

const App: React.FC = () => {
  const [step, setStep] = useState<'form' | 'welcome'>('form');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [welcomeNote, setWelcomeNote] = useState('');

  const handleRegistration = async (newProfile: UserProfile) => {
    setIsSubmitting(true);
    try {
      // Simulate API registration delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Use Gemini to create a personalized welcome based on their profile
      const message = await generateWelcomeMessage(newProfile);
      
      setProfile(newProfile);
      setWelcomeNote(message);
      setStep('welcome');
    } catch (error) {
      console.error("Registration error:", error);
      alert("Houve um erro no cadastro. Tente novamente.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Layout>
      <div className="max-w-3xl mx-auto">
        {step === 'form' ? (
          <div className="space-y-12">
            <section className="text-center space-y-4">
              <h1 className="text-4xl sm:text-6xl font-serif text-white leading-tight">
                Liberte seus <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-400 to-purple-500">Desejos</span>
              </h1>
              <p className="text-lg text-slate-400 max-w-xl mx-auto">
                O Portal de Acesso Swing Love é a porta de entrada para uma comunidade seleta, onde o respeito e a discrição são as nossas únicas regras.
              </p>
            </section>

            <div className="relative">
              {/* Floating decorative elements */}
              <div className="absolute -top-10 -left-10 w-32 h-32 bg-rose-500/10 rounded-full blur-3xl pointer-events-none"></div>
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>
              
              <RegistrationForm onSubmit={handleRegistration} isSubmitting={isSubmitting} />
            </div>

            <section className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-10">
              <div className="p-6 bg-slate-900/30 rounded-2xl border border-slate-800">
                <div className="text-rose-400 mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <h3 className="text-white font-medium mb-1">Total Sigilo</h3>
                <p className="text-xs text-slate-500">Suas fotos e dados pessoais nunca são expostos externamente.</p>
              </div>
              <div className="p-6 bg-slate-900/30 rounded-2xl border border-slate-800">
                <div className="text-purple-400 mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <h3 className="text-white font-medium mb-1">Verificação</h3>
                <p className="text-xs text-slate-500">Membros verificados garantem uma comunidade real e segura.</p>
              </div>
              <div className="p-6 bg-slate-900/30 rounded-2xl border border-slate-800">
                <div className="text-rose-400 mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                </div>
                <h3 className="text-white font-medium mb-1">Liberdade</h3>
                <p className="text-xs text-slate-500">Expanda seus horizontes e viva experiências únicas e intensas.</p>
              </div>
            </section>
          </div>
        ) : (
          profile && (
            <WelcomeScreen 
              profile={profile} 
              welcomeNote={welcomeNote} 
            />
          )
        )}
      </div>
    </Layout>
  );
};

export default App;
