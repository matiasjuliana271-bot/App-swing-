
export enum RelationshipStatus {
  COUPLE = 'Casal',
  SINGLE_FEMALE = 'Mulher Single',
  SINGLE_MALE = 'Homem Single',
}

export interface UserProfile {
  name: string;
  age: number;
  location: string;
  status: RelationshipStatus;
  interests: string[];
  whatsapp: string;
  bio: string;
}

export interface RegistrationResponse {
  success: boolean;
  message: string;
  welcomeNote?: string;
}
