
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 selection:bg-rose-500/30">
      {/* Background decoration */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-900 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-rose-900 rounded-full blur-[120px]" />
      </div>

      <header className="relative z-10 border-b border-slate-800 bg-slate-950/50 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-br from-rose-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg shadow-rose-500/20">
              <span className="text-white font-bold text-xl">SL</span>
            </div>
            <h1 className="text-xl font-serif tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-rose-400 to-purple-400 uppercase">
              Swing Love
            </h1>
          </div>
          <div className="hidden sm:block text-xs uppercase tracking-widest text-slate-500 font-medium">
            Exclusividade • Discrição • Prazer
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-4xl mx-auto px-4 py-8 sm:py-12">
        {children}
      </main>

      <footer className="relative z-10 py-8 border-t border-slate-900 text-center text-slate-600 text-sm">
        <p>&copy; 2024 Swing Love. Conteúdo para maiores de 18 anos.</p>
      </footer>
    </div>
  );
};
